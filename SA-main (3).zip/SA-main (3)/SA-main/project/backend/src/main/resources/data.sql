INSERT INTO personaldata (realname, email, password, role) VALUES ('Admin','admin@gmail.com','adminpassword','admin');
